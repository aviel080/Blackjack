package bj;

public class LoginManager {

	public void userLogin(User user) throws Exception
	{
		//Match User;
		
	}
}
