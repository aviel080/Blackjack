package bj;

public class Controller {
	public int hitController()
	{
		return 0;
	}
	public void doubleController()
	{
		
	}
	public void holdController()
	{
		
	}
	public void splitController()
	{
		
	}
	public void surrenderController()
	{
		
	}
	public void loginController()
	{
		
	}
	public void signupController()
	{
		
	}
	public void playController()
	{
		
	}
	public void depositController()
	{
		
	}
	public void withdrawController()
	{
		
	}
	public void statisticsController()
	{
		
	}
	
}
